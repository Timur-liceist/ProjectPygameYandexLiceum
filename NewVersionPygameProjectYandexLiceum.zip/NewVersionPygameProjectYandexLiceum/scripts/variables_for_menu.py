import pygame
all_sprites = pygame.sprite.Group()
WIDTH, HEIGHT = SIZE = (650, 500)
screen = pygame.display.set_mode(SIZE)
color_before = (255, 165, 0)
color_after = (255, 235, 0)